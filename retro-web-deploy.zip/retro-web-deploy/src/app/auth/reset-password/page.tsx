import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function ResetPassword() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token') || '';
  const email = searchParams.get('email') || '';
  
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    if (newPassword !== confirmPassword) {
      setError('As senhas não coincidem.');
      setLoading(false);
      return;
    }

    if (newPassword.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email,
          token,
          newPassword 
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao redefinir senha');
      }
      
      setSuccess(true);
      setMessage('Senha redefinida com sucesso! Você já pode fazer login com sua nova senha.');
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!token || !email) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="retro-header w-full max-w-md text-center mb-8">
          <h1 className="text-3xl">RETRO WEB</h1>
          <p>Redefinição de Senha</p>
        </div>

        <div className="retro-card w-full max-w-md">
          <h2 className="text-2xl font-bold mb-6 text-center">LINK INVÁLIDO</h2>
          <p className="text-center mb-6">O link de redefinição de senha é inválido ou expirou.</p>
          <div className="mt-6 text-center">
            <Link href="/auth/forgot-password" className="retro-button bg-blue-400 inline-block">
              SOLICITAR NOVO LINK
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="retro-header w-full max-w-md text-center mb-8">
        <h1 className="text-3xl">RETRO WEB</h1>
        <p>Redefinição de Senha</p>
      </div>

      <div className="retro-card w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">NOVA SENHA</h2>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        {message && (
          <div className="bg-green-100 border-2 border-green-500 text-green-700 p-3 mb-4 text-center">
            {message}
          </div>
        )}
        
        {!success ? (
          <form onSubmit={handleSubmit} className="retro-form">
            <div className="retro-form-group">
              <label className="retro-form-label">NOVA SENHA:</label>
              <input 
                type="password" 
                className="retro-input" 
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            
            <div className="retro-form-group">
              <label className="retro-form-label">CONFIRMAR SENHA:</label>
              <input 
                type="password" 
                className="retro-input" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            
            <div className="mt-6">
              <button 
                type="submit" 
                className="retro-button bg-green-400 w-full"
                disabled={loading}
              >
                {loading ? 'REDEFININDO...' : 'REDEFINIR SENHA'}
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-6 text-center">
            <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
              IR PARA LOGIN
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
