import { useState } from 'react';
import Link from 'next/link';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao processar solicitação');
      }
      
      setSuccess(true);
      setMessage('Instruções de recuperação foram enviadas para seu e-mail. Verifique sua caixa de entrada.');
      
      // Em ambiente de desenvolvimento, mostrar link direto (remover em produção)
      if (data.resetUrl) {
        setMessage(prev => `${prev} Para fins de demonstração, você pode acessar: ${data.resetUrl}`);
      }
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="retro-header w-full max-w-md text-center mb-8">
        <h1 className="text-3xl">RETRO WEB</h1>
        <p>Recuperação de Senha</p>
      </div>

      <div className="retro-card w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">ESQUECEU SUA SENHA?</h2>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        {message && (
          <div className="bg-green-100 border-2 border-green-500 text-green-700 p-3 mb-4 text-center">
            {message}
          </div>
        )}
        
        {!success ? (
          <form onSubmit={handleSubmit} className="retro-form">
            <div className="retro-form-group">
              <label className="retro-form-label">E-MAIL:</label>
              <input 
                type="email" 
                className="retro-input" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="mt-6">
              <button 
                type="submit" 
                className="retro-button bg-green-400 w-full"
                disabled={loading}
              >
                {loading ? 'ENVIANDO...' : 'ENVIAR INSTRUÇÕES'}
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-6 text-center">
            <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
              VOLTAR PARA LOGIN
            </Link>
          </div>
        )}
        
        <div className="mt-6 text-center">
          <Link href="/auth/login" className="retro-link">
            Lembrou sua senha? Voltar para login
          </Link>
        </div>
      </div>
    </div>
  );
}
