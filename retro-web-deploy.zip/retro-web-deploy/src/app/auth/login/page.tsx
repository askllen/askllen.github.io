import { useState } from 'react';
import Link from 'next/link';
import { signIn } from '@/app/auth/route';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const result = await signIn('credentials', {
        email,
        password,
        redirect: true,
        redirectTo: '/'
      });
      
      if (!result?.ok) {
        setError('Credenciais inválidas. Tente novamente.');
      }
    } catch (err) {
      setError('Ocorreu um erro ao fazer login. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="retro-header w-full max-w-md text-center mb-8">
        <h1 className="text-3xl">RETRO WEB</h1>
        <p>Login</p>
      </div>

      <div className="retro-card w-full max-w-md border-4 border-yellow-400 bg-yellow-100">
        <h2 className="text-2xl font-bold mb-6 text-center">TELA DE ACESSO</h2>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="retro-form">
          <div className="retro-form-group">
            <label className="retro-form-label">E-MAIL:</label>
            <input 
              type="email" 
              className="retro-input" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">SENHA:</label>
            <input 
              type="password" 
              className="retro-input" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <div className="text-right">
            <Link href="/auth/forgot-password" className="text-red-500 text-sm">
              ESQUECEU A SENHA?
            </Link>
          </div>
          
          <div className="mt-6 space-y-4">
            <button 
              type="submit" 
              className="retro-button bg-green-400 w-full"
              disabled={loading}
            >
              {loading ? 'ENTRANDO...' : 'ENTRAR'}
            </button>
            
            <div className="text-center">ou</div>
            
            <button 
              type="button" 
              className="retro-button bg-blue-400 w-full"
              onClick={() => signIn('google', { redirectTo: '/' })}
              disabled={loading}
            >
              ENTRAR COM GOOGLE
            </button>
            
            <button 
              type="button" 
              className="retro-button bg-blue-600 w-full"
              onClick={() => signIn('facebook', { redirectTo: '/' })}
              disabled={loading}
            >
              ENTRAR COM FACEBOOK
            </button>
            
            <button 
              type="button" 
              className="retro-button bg-gray-800 text-white w-full"
              onClick={() => signIn('apple', { redirectTo: '/' })}
              disabled={loading}
            >
              ENTRAR COM APPLE
            </button>
          </div>
          
          <div className="mt-6 text-center">
            <p>Não tem uma conta?</p>
            <Link href="/auth/register" className="retro-button bg-yellow-400 inline-block mt-2">
              CADASTRE-SE
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
