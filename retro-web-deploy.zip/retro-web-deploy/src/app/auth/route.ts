import NextAuth from "next-auth";
import { D1Adapter } from "@auth/d1-adapter";
import Credentials from "next-auth/providers/credentials";
import Google from "next-auth/providers/google";
import Facebook from "next-auth/providers/facebook";
import Apple from "next-auth/providers/apple";
import { getCloudflareContext } from "@/lib/cloudflare";
import bcrypt from "bcryptjs";

export const { auth, signIn, signOut } = NextAuth({
  adapter: {
    async createAdapter(context) {
      const { env } = getCloudflareContext(context);
      if (!env?.DB) return null;
      return D1Adapter(env.DB);
    }
  },
  pages: {
    signIn: "/auth/login",
    signUp: "/auth/register",
    error: "/auth/error",
    verifyRequest: "/auth/verify-request",
  },
  providers: [
    Credentials({
      name: "Credenciais",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" }
      },
      async authorize(credentials, req) {
        const { env } = getCloudflareContext(req);
        if (!env?.DB || !credentials?.email || !credentials?.password) return null;
        
        const user = await env.DB.prepare(
          "SELECT * FROM users WHERE email = ?"
        ).bind(credentials.email).first();
        
        if (!user || !user.password) return null;
        
        const isValid = await bcrypt.compare(credentials.password, user.password);
        
        if (!isValid) return null;
        
        return {
          id: user.id,
          name: user.name,
          email: user.email,
          image: user.image,
        };
      }
    }),
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    }),
    Facebook({
      clientId: process.env.FACEBOOK_CLIENT_ID,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    }),
    Apple({
      clientId: process.env.APPLE_CLIENT_ID,
      clientSecret: process.env.APPLE_CLIENT_SECRET,
    }),
  ],
  callbacks: {
    async session({ session, user }) {
      if (session.user) {
        session.user.id = user.id;
      }
      return session;
    },
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
      }
      return token;
    }
  },
  secret: process.env.NEXTAUTH_SECRET || "seu-segredo-temporario-para-desenvolvimento",
});
