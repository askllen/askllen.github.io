import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import bcrypt from 'bcryptjs';

export default function Register() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    birthDate: '',
    documentType: 'CPF',
    documentNumber: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
    zipCode: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateStep1 = () => {
    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      setError('Todos os campos são obrigatórios.');
      return false;
    }
    
    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem.');
      return false;
    }
    
    if (formData.password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      return false;
    }
    
    return true;
  };

  const validateStep2 = () => {
    if (!formData.birthDate || !formData.documentType || !formData.documentNumber) {
      setError('Todos os campos são obrigatórios.');
      return false;
    }
    
    return true;
  };

  const validateStep3 = () => {
    if (!formData.street || !formData.number || !formData.neighborhood || !formData.city || !formData.state || !formData.zipCode) {
      setError('Todos os campos são obrigatórios, exceto complemento.');
      return false;
    }
    
    return true;
  };

  const nextStep = () => {
    setError('');
    
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    }
  };

  const prevStep = () => {
    setError('');
    setStep(step - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStep3()) {
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      // Hash da senha
      const hashedPassword = await bcrypt.hash(formData.password, 10);
      
      // Preparar dados para envio
      const userData = {
        ...formData,
        password: hashedPassword,
      };
      
      // Enviar para API
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Erro ao cadastrar usuário');
      }
      
      // Redirecionar para login
      router.push('/auth/login?registered=true');
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro ao cadastrar. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="retro-header w-full max-w-md text-center mb-8">
        <h1 className="text-3xl">RETRO WEB</h1>
        <p>Cadastro</p>
      </div>

      <div className="retro-card w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">CADASTRE-SE</h2>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        <div className="flex justify-between mb-6">
          <div className={`w-1/3 p-2 text-center ${step === 1 ? 'bg-yellow-400 border-2 border-black' : 'bg-gray-200'}`}>
            Dados de Acesso
          </div>
          <div className={`w-1/3 p-2 text-center ${step === 2 ? 'bg-yellow-400 border-2 border-black' : 'bg-gray-200'}`}>
            Dados Pessoais
          </div>
          <div className={`w-1/3 p-2 text-center ${step === 3 ? 'bg-yellow-400 border-2 border-black' : 'bg-gray-200'}`}>
            Endereço
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="retro-form">
          {step === 1 && (
            <>
              <div className="retro-form-group">
                <label className="retro-form-label">NOME COMPLETO:</label>
                <input 
                  type="text" 
                  name="name"
                  className="retro-input" 
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">E-MAIL:</label>
                <input 
                  type="email" 
                  name="email"
                  className="retro-input" 
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">SENHA:</label>
                <input 
                  type="password" 
                  name="password"
                  className="retro-input" 
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">CONFIRMAR SENHA:</label>
                <input 
                  type="password" 
                  name="confirmPassword"
                  className="retro-input" 
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
              </div>
            </>
          )}
          
          {step === 2 && (
            <>
              <div className="retro-form-group">
                <label className="retro-form-label">DATA DE NASCIMENTO:</label>
                <input 
                  type="date" 
                  name="birthDate"
                  className="retro-input" 
                  value={formData.birthDate}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">TIPO DE DOCUMENTO:</label>
                <select 
                  name="documentType"
                  className="retro-input" 
                  value={formData.documentType}
                  onChange={handleChange}
                  required
                >
                  <option value="CPF">CPF</option>
                  <option value="Identidade">Identidade</option>
                  <option value="Passport">Passaporte</option>
                </select>
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">NÚMERO DO DOCUMENTO:</label>
                <input 
                  type="text" 
                  name="documentNumber"
                  className="retro-input" 
                  value={formData.documentNumber}
                  onChange={handleChange}
                  required
                />
              </div>
            </>
          )}
          
          {step === 3 && (
            <>
              <div className="retro-form-group">
                <label className="retro-form-label">RUA:</label>
                <input 
                  type="text" 
                  name="street"
                  className="retro-input" 
                  value={formData.street}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">NÚMERO:</label>
                <input 
                  type="text" 
                  name="number"
                  className="retro-input" 
                  value={formData.number}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">COMPLEMENTO:</label>
                <input 
                  type="text" 
                  name="complement"
                  className="retro-input" 
                  value={formData.complement}
                  onChange={handleChange}
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">BAIRRO:</label>
                <input 
                  type="text" 
                  name="neighborhood"
                  className="retro-input" 
                  value={formData.neighborhood}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">CIDADE:</label>
                <input 
                  type="text" 
                  name="city"
                  className="retro-input" 
                  value={formData.city}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">ESTADO:</label>
                <input 
                  type="text" 
                  name="state"
                  className="retro-input" 
                  value={formData.state}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="retro-form-group">
                <label className="retro-form-label">CEP:</label>
                <input 
                  type="text" 
                  name="zipCode"
                  className="retro-input" 
                  value={formData.zipCode}
                  onChange={handleChange}
                  required
                />
              </div>
            </>
          )}
          
          <div className="mt-6 flex justify-between">
            {step > 1 && (
              <button 
                type="button" 
                className="retro-button bg-gray-400"
                onClick={prevStep}
              >
                VOLTAR
              </button>
            )}
            
            {step < 3 ? (
              <button 
                type="button" 
                className="retro-button bg-blue-400 ml-auto"
                onClick={nextStep}
              >
                PRÓXIMO
              </button>
            ) : (
              <button 
                type="submit" 
                className="retro-button bg-green-400 ml-auto"
                disabled={loading}
              >
                {loading ? 'CADASTRANDO...' : 'FINALIZAR CADASTRO'}
              </button>
            )}
          </div>
          
          <div className="mt-6 text-center">
            <p>Já tem uma conta?</p>
            <Link href="/auth/login" className="retro-button bg-yellow-400 inline-block mt-2">
              FAZER LOGIN
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
