import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

export default function EmailSettings() {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    emailProvider: 'Gmail',
    imapServer: 'imap.gmail.com',
    imapPort: '993',
    smtpServer: 'smtp.gmail.com',
    smtpPort: '465',
    username: '',
    password: ''
  });

  useEffect(() => {
    // Carregar configurações existentes se o usuário estiver logado
    if (session?.user?.id) {
      fetchSettings();
    }
  }, [session]);

  const fetchSettings = async () => {
    try {
      const response = await fetch(`/api/email/settings?userId=${session.user.id}`);
      if (response.ok) {
        const data = await response.json();
        if (data.settings) {
          setFormData({
            emailProvider: data.settings.email_provider,
            imapServer: data.settings.imap_server,
            imapPort: data.settings.imap_port,
            smtpServer: data.settings.smtp_server,
            smtpPort: data.settings.smtp_port,
            username: data.settings.username,
            password: data.settings.password
          });
        }
      }
    } catch (error) {
      console.error('Erro ao carregar configurações:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProviderChange = (e) => {
    const provider = e.target.value;
    let newFormData = { ...formData, emailProvider: provider };
    
    // Preencher automaticamente os servidores com base no provedor
    if (provider === 'Gmail') {
      newFormData = {
        ...newFormData,
        imapServer: 'imap.gmail.com',
        imapPort: '993',
        smtpServer: 'smtp.gmail.com',
        smtpPort: '465'
      };
    } else if (provider === 'Outlook') {
      newFormData = {
        ...newFormData,
        imapServer: 'outlook.office365.com',
        imapPort: '993',
        smtpServer: 'smtp.office365.com',
        smtpPort: '587'
      };
    } else if (provider === 'Yahoo') {
      newFormData = {
        ...newFormData,
        imapServer: 'imap.mail.yahoo.com',
        imapPort: '993',
        smtpServer: 'smtp.mail.yahoo.com',
        smtpPort: '465'
      };
    }
    
    setFormData(newFormData);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch('/api/email/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: session.user.id,
          emailProvider: formData.emailProvider,
          imapServer: formData.imapServer,
          imapPort: formData.imapPort,
          smtpServer: formData.smtpServer,
          smtpPort: formData.smtpPort,
          username: formData.username,
          password: formData.password
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao salvar configurações');
      }
      
      setMessage('Configurações de e-mail salvas com sucesso!');
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao salvar as configurações.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="retro-header">
        <h1 className="text-3xl">CONFIGURAÇÕES DE E-MAIL</h1>
      </div>

      <div className="retro-card">
        <h2 className="text-2xl font-bold mb-6">Conecte sua conta de e-mail</h2>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        {message && (
          <div className="bg-green-100 border-2 border-green-500 text-green-700 p-3 mb-4 text-center">
            {message}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="retro-form">
          <div className="retro-form-group">
            <label className="retro-form-label">PROVEDOR DE E-MAIL:</label>
            <select 
              name="emailProvider"
              className="retro-input" 
              value={formData.emailProvider}
              onChange={handleProviderChange}
              required
            >
              <option value="Gmail">Gmail</option>
              <option value="Outlook">Outlook</option>
              <option value="Yahoo">Yahoo</option>
              <option value="Outro">Outro</option>
            </select>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="retro-form-group">
              <label className="retro-form-label">SERVIDOR IMAP:</label>
              <input 
                type="text" 
                name="imapServer"
                className="retro-input" 
                value={formData.imapServer}
                onChange={handleChange}
                required
              />
            </div>
            
            <div className="retro-form-group">
              <label className="retro-form-label">PORTA IMAP:</label>
              <input 
                type="text" 
                name="imapPort"
                className="retro-input" 
                value={formData.imapPort}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="retro-form-group">
              <label className="retro-form-label">SERVIDOR SMTP:</label>
              <input 
                type="text" 
                name="smtpServer"
                className="retro-input" 
                value={formData.smtpServer}
                onChange={handleChange}
                required
              />
            </div>
            
            <div className="retro-form-group">
              <label className="retro-form-label">PORTA SMTP:</label>
              <input 
                type="text" 
                name="smtpPort"
                className="retro-input" 
                value={formData.smtpPort}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">E-MAIL:</label>
            <input 
              type="email" 
              name="username"
              className="retro-input" 
              value={formData.username}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">SENHA:</label>
            <input 
              type="password" 
              name="password"
              className="retro-input" 
              value={formData.password}
              onChange={handleChange}
              required
            />
            <p className="text-sm text-gray-600 mt-1">
              Nota: Para Gmail, você pode precisar criar uma "senha de app" nas configurações de segurança da sua conta Google.
            </p>
          </div>
          
          <div className="mt-6 flex justify-between">
            <Link href="/email" className="retro-button bg-gray-400">
              CANCELAR
            </Link>
            <button 
              type="submit" 
              className="retro-button bg-green-400"
              disabled={loading}
            >
              {loading ? 'SALVANDO...' : 'SALVAR CONFIGURAÇÕES'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
