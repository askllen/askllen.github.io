import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

export default function EmailClient() {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [emails, setEmails] = useState([]);
  const [selectedFolder, setSelectedFolder] = useState('INBOX');
  const [hasEmailConfig, setHasEmailConfig] = useState(false);
  
  const folders = [
    { id: 'INBOX', name: 'Caixa de Entrada' },
    { id: 'SENT', name: 'Enviados' },
    { id: 'DRAFTS', name: 'Rascunhos' },
    { id: 'TRASH', name: 'Lixeira' },
    { id: 'SPAM', name: 'Spam' }
  ];

  useEffect(() => {
    if (session?.user?.id) {
      checkEmailConfig();
    }
  }, [session]);

  useEffect(() => {
    if (hasEmailConfig) {
      fetchEmails();
    }
  }, [hasEmailConfig, selectedFolder]);

  const checkEmailConfig = async () => {
    try {
      const response = await fetch(`/api/email/settings?userId=${session.user.id}`);
      if (response.ok) {
        const data = await response.json();
        setHasEmailConfig(!!data.settings);
      } else {
        setHasEmailConfig(false);
      }
    } catch (error) {
      console.error('Erro ao verificar configurações de e-mail:', error);
      setHasEmailConfig(false);
    } finally {
      setLoading(false);
    }
  };

  const fetchEmails = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/email/list', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: session.user.id,
          folder: selectedFolder,
          limit: 20
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao buscar e-mails');
      }
      
      setEmails(data.messages || []);
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao buscar os e-mails.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  if (loading && !hasEmailConfig) {
    return (
      <div className="retro-card">
        <p className="text-center">Carregando...</p>
      </div>
    );
  }

  if (!hasEmailConfig) {
    return (
      <div className="min-h-screen">
        <div className="retro-header">
          <h1 className="text-3xl">E-MAIL RETRO</h1>
        </div>

        <div className="retro-card">
          <h2 className="text-2xl font-bold mb-6 text-center">CONFIGURAÇÃO NECESSÁRIA</h2>
          <p className="text-center mb-6">
            Você ainda não configurou sua conta de e-mail. Configure agora para começar a usar o cliente de e-mail.
          </p>
          <div className="text-center">
            <Link href="/email/settings" className="retro-button bg-green-400 inline-block">
              CONFIGURAR E-MAIL
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="retro-header">
        <h1 className="text-3xl">E-MAIL RETRO</h1>
      </div>

      <div className="retro-email-container">
        {/* Sidebar com pastas e ações */}
        <div className="retro-email-sidebar">
          <div className="mb-4">
            <Link href="/email/compose" className="retro-button bg-green-400 w-full block text-center">
              NOVA MENSAGEM
            </Link>
          </div>
          
          <div className="mb-4">
            <h3 className="font-bold mb-2">PASTAS</h3>
            <ul>
              {folders.map(folder => (
                <li 
                  key={folder.id}
                  className={`retro-email-item cursor-pointer ${selectedFolder === folder.id ? 'bg-yellow-300' : ''}`}
                  onClick={() => setSelectedFolder(folder.id)}
                >
                  {folder.name}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mt-auto">
            <Link href="/email/settings" className="retro-button bg-blue-400 w-full block text-center">
              CONFIGURAÇÕES
            </Link>
          </div>
        </div>

        {/* Conteúdo principal */}
        <div className="retro-email-content">
          <h2 className="text-xl font-bold mb-4">{folders.find(f => f.id === selectedFolder)?.name}</h2>
          
          {error && (
            <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
              {error}
            </div>
          )}
          
          {loading ? (
            <p className="text-center">Carregando e-mails...</p>
          ) : emails.length > 0 ? (
            <div className="border-2 border-black">
              {emails.map((email) => (
                <Link 
                  href={`/email/view?uid=${email.uid}&folder=${selectedFolder}`}
                  key={email.uid}
                  className="block border-b-2 border-black p-2 hover:bg-yellow-100"
                >
                  <div className="flex justify-between">
                    <div className="font-bold">{email.from[0]?.name || email.from[0]?.email}</div>
                    <div className="text-sm">{formatDate(email.date)}</div>
                  </div>
                  <div className="font-bold">{email.subject || '(Sem assunto)'}</div>
                  <div className="text-sm truncate">{email.preview}</div>
                  {email.hasAttachments && (
                    <div className="text-xs text-gray-600">📎 Com anexos</div>
                  )}
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-center">Nenhum e-mail encontrado nesta pasta.</p>
          )}
          
          <div className="mt-4 text-right">
            <button 
              onClick={fetchEmails} 
              className="retro-button bg-blue-400"
              disabled={loading}
            >
              ATUALIZAR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
