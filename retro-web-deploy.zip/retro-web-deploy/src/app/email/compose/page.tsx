import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function ComposeEmail() {
  const { data: session } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();
  
  // Verificar se é uma resposta a um e-mail existente
  const replyTo = searchParams.get('replyTo');
  const replySubject = searchParams.get('subject');
  const replyEmail = searchParams.get('email');
  
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [hasEmailConfig, setHasEmailConfig] = useState(false);
  const [formData, setFormData] = useState({
    to: replyEmail || '',
    cc: '',
    bcc: '',
    subject: replySubject ? `Re: ${replySubject}` : '',
    body: '',
    attachments: []
  });

  useEffect(() => {
    if (session?.user?.id) {
      checkEmailConfig();
    }
  }, [session]);

  const checkEmailConfig = async () => {
    try {
      const response = await fetch(`/api/email/settings?userId=${session.user.id}`);
      if (response.ok) {
        const data = await response.json();
        setHasEmailConfig(!!data.settings);
      } else {
        setHasEmailConfig(false);
      }
    } catch (error) {
      console.error('Erro ao verificar configurações de e-mail:', error);
      setHasEmailConfig(false);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Limitar a 5 arquivos
    if (formData.attachments.length + files.length > 5) {
      setError('Máximo de 5 anexos permitidos.');
      return;
    }
    
    // Verificar tipos de arquivo permitidos (apenas imagens e PDFs)
    const invalidFiles = files.filter(file => 
      !file.type.startsWith('image/') && file.type !== 'application/pdf'
    );
    
    if (invalidFiles.length > 0) {
      setError('Apenas imagens e PDFs são permitidos como anexos.');
      return;
    }
    
    // Processar arquivos válidos
    Promise.all(
      files.map(file => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            resolve({
              filename: file.name,
              content: reader.result.split(',')[1], // Remover prefixo data:...;base64,
              type: file.type,
              size: file.size
            });
          };
          reader.readAsDataURL(file);
        });
      })
    ).then(newAttachments => {
      setFormData(prev => ({
        ...prev,
        attachments: [...prev.attachments, ...newAttachments]
      }));
      setError('');
    });
  };

  const removeAttachment = (index) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    setError('');

    try {
      const response = await fetch('/api/email/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: session.user.id,
          to: formData.to,
          cc: formData.cc || undefined,
          bcc: formData.bcc || undefined,
          subject: formData.subject,
          body: formData.body,
          attachments: formData.attachments
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao enviar e-mail');
      }
      
      // Redirecionar para a caixa de entrada após envio bem-sucedido
      router.push('/email?sent=true');
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao enviar o e-mail.');
      console.error(err);
      setSending(false);
    }
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="retro-card">
        <p className="text-center">Carregando...</p>
      </div>
    );
  }

  if (!hasEmailConfig) {
    return (
      <div className="min-h-screen">
        <div className="retro-header">
          <h1 className="text-3xl">E-MAIL RETRO</h1>
        </div>

        <div className="retro-card">
          <h2 className="text-2xl font-bold mb-6 text-center">CONFIGURAÇÃO NECESSÁRIA</h2>
          <p className="text-center mb-6">
            Você ainda não configurou sua conta de e-mail. Configure agora para começar a usar o cliente de e-mail.
          </p>
          <div className="text-center">
            <Link href="/email/settings" className="retro-button bg-green-400 inline-block">
              CONFIGURAR E-MAIL
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="retro-header">
        <h1 className="text-3xl">NOVA MENSAGEM</h1>
      </div>

      <div className="retro-card">
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="retro-form">
          <div className="retro-form-group">
            <label className="retro-form-label">PARA:</label>
            <input 
              type="text" 
              name="to"
              className="retro-input" 
              value={formData.to}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">CC:</label>
            <input 
              type="text" 
              name="cc"
              className="retro-input" 
              value={formData.cc}
              onChange={handleChange}
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">CCO:</label>
            <input 
              type="text" 
              name="bcc"
              className="retro-input" 
              value={formData.bcc}
              onChange={handleChange}
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">ASSUNTO:</label>
            <input 
              type="text" 
              name="subject"
              className="retro-input" 
              value={formData.subject}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">MENSAGEM:</label>
            <textarea 
              name="body"
              className="retro-input h-64" 
              value={formData.body}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="retro-form-group">
            <label className="retro-form-label">ANEXOS:</label>
            <input 
              type="file" 
              className="retro-input" 
              onChange={handleFileChange}
              multiple
              accept="image/*,application/pdf"
            />
            <p className="text-sm text-gray-600 mt-1">
              Máximo de 5 anexos. Apenas imagens e PDFs são permitidos.
            </p>
            
            {formData.attachments.length > 0 && (
              <div className="mt-2 border-2 border-black p-2">
                <h4 className="font-bold mb-2">Arquivos anexados:</h4>
                <ul>
                  {formData.attachments.map((file, index) => (
                    <li key={index} className="flex justify-between items-center mb-1">
                      <span>{file.filename} ({Math.round(file.size / 1024)} KB)</span>
                      <button 
                        type="button"
                        className="text-red-500"
                        onClick={() => removeAttachment(index)}
                      >
                        Remover
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          
          <div className="mt-6 flex justify-between">
            <Link href="/email" className="retro-button bg-gray-400">
              CANCELAR
            </Link>
            <button 
              type="submit" 
              className="retro-button bg-green-400"
              disabled={sending}
            >
              {sending ? 'ENVIANDO...' : 'ENVIAR MENSAGEM'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
