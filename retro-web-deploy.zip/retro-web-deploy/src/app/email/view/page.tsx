import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function ViewEmail() {
  const { data: session } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const uid = searchParams.get('uid');
  const folder = searchParams.get('folder') || 'INBOX';
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [email, setEmail] = useState(null);
  const [hasEmailConfig, setHasEmailConfig] = useState(false);

  useEffect(() => {
    if (session?.user?.id) {
      checkEmailConfig();
    }
  }, [session]);

  useEffect(() => {
    if (hasEmailConfig && uid) {
      fetchEmail();
    }
  }, [hasEmailConfig, uid, folder]);

  const checkEmailConfig = async () => {
    try {
      const response = await fetch(`/api/email/settings?userId=${session.user.id}`);
      if (response.ok) {
        const data = await response.json();
        setHasEmailConfig(!!data.settings);
      } else {
        setHasEmailConfig(false);
      }
    } catch (error) {
      console.error('Erro ao verificar configurações de e-mail:', error);
      setHasEmailConfig(false);
    }
  };

  const fetchEmail = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/email/view', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: session.user.id,
          uid,
          folder
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Erro ao buscar e-mail');
      }
      
      setEmail(data.message);
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao buscar o e-mail.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleReply = () => {
    if (!email) return;
    
    const replyEmail = email.from[0]?.email;
    const replySubject = email.subject;
    
    router.push(`/email/compose?replyTo=${uid}&email=${encodeURIComponent(replyEmail)}&subject=${encodeURIComponent(replySubject)}`);
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  if (!uid) {
    return (
      <div className="retro-card">
        <p className="text-center">E-mail não encontrado.</p>
        <div className="mt-4 text-center">
          <Link href="/email" className="retro-button bg-blue-400 inline-block">
            VOLTAR PARA CAIXA DE ENTRADA
          </Link>
        </div>
      </div>
    );
  }

  if (loading && !email) {
    return (
      <div className="retro-card">
        <p className="text-center">Carregando e-mail...</p>
      </div>
    );
  }

  if (!hasEmailConfig) {
    return (
      <div className="min-h-screen">
        <div className="retro-header">
          <h1 className="text-3xl">E-MAIL RETRO</h1>
        </div>

        <div className="retro-card">
          <h2 className="text-2xl font-bold mb-6 text-center">CONFIGURAÇÃO NECESSÁRIA</h2>
          <p className="text-center mb-6">
            Você ainda não configurou sua conta de e-mail. Configure agora para começar a usar o cliente de e-mail.
          </p>
          <div className="text-center">
            <Link href="/email/settings" className="retro-button bg-green-400 inline-block">
              CONFIGURAR E-MAIL
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="retro-header">
        <h1 className="text-3xl">E-MAIL RETRO</h1>
      </div>

      <div className="retro-card">
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        <div className="mb-4 flex justify-between">
          <Link href="/email" className="retro-button bg-blue-400">
            VOLTAR
          </Link>
          <div>
            <button 
              onClick={handleReply} 
              className="retro-button bg-green-400 mr-2"
            >
              RESPONDER
            </button>
            <Link 
              href={`/email/compose?replyTo=${uid}&email=${encodeURIComponent(email?.from[0]?.email || '')}&subject=Fw: ${encodeURIComponent(email?.subject || '')}`} 
              className="retro-button bg-yellow-400"
            >
              ENCAMINHAR
            </Link>
          </div>
        </div>
        
        {email && (
          <div className="border-2 border-black p-4">
            <div className="mb-4 border-b-2 border-black pb-2">
              <h2 className="text-2xl font-bold">{email.subject || '(Sem assunto)'}</h2>
              <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2">
                <div>
                  <p><strong>De:</strong> {email.from[0]?.name || ''} &lt;{email.from[0]?.email || ''}&gt;</p>
                  <p><strong>Para:</strong> {email.to.map(t => `${t.name || ''} <${t.email}>`).join(', ')}</p>
                  {email.cc && email.cc.length > 0 && (
                    <p><strong>CC:</strong> {email.cc.map(c => `${c.name || ''} <${c.email}>`).join(', ')}</p>
                  )}
                </div>
                <div className="text-right">
                  <p><strong>Data:</strong> {formatDate(email.date)}</p>
                </div>
              </div>
            </div>
            
            <div className="mb-4 whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: email.body }} />
            
            {email.attachments && email.attachments.length > 0 && (
              <div className="mt-4 border-t-2 border-black pt-2">
                <h3 className="font-bold mb-2">Anexos:</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {email.attachments.map((attachment, index) => (
                    <li key={index} className="border-2 border-black p-2">
                      <p>{attachment.filename}</p>
                      <p className="text-sm text-gray-600">
                        {attachment.contentType}, {Math.round(attachment.size / 1024)} KB
                      </p>
                      <button 
                        className="retro-button bg-blue-400 mt-2 text-sm"
                        onClick={() => window.open(`/api/email/attachment?userId=${session.user.id}&uid=${uid}&folder=${folder}&partId=${attachment.partId}`, '_blank')}
                      >
                        BAIXAR
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
