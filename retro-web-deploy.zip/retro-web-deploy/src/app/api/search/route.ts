import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get('q');
    
    if (!query) {
      return NextResponse.json(
        { message: 'Parâmetro de busca obrigatório' },
        { status: 400 }
      );
    }

    // Fazer requisição para a API do DuckDuckGo
    const response = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json`);
    
    if (!response.ok) {
      throw new Error(`Erro na API do DuckDuckGo: ${response.status}`);
    }
    
    const data = await response.json();
    
    return NextResponse.json(data);
  } catch (error) {
    console.error('Erro ao buscar resultados:', error);
    return NextResponse.json(
      { message: 'Erro ao buscar resultados' },
      { status: 500 }
    );
  }
}
