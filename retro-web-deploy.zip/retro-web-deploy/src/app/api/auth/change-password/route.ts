import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import bcrypt from 'bcryptjs';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    
    // Validação básica
    if (!data.email || !data.oldPassword || !data.newPassword) {
      return NextResponse.json(
        { message: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      );
    }

    // Buscar usuário
    const user = await env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(data.email).first();

    if (!user) {
      return NextResponse.json(
        { message: 'Usuário não encontrado' },
        { status: 404 }
      );
    }

    // Verificar senha atual
    const isValid = await bcrypt.compare(data.oldPassword, user.password);
    
    if (!isValid) {
      return NextResponse.json(
        { message: 'Senha atual incorreta' },
        { status: 401 }
      );
    }

    // Hash da nova senha
    const hashedPassword = await bcrypt.hash(data.newPassword, 10);

    // Atualizar senha
    await env.DB.prepare(`
      UPDATE users SET password = ? WHERE id = ?
    `).bind(
      hashedPassword,
      user.id
    ).run();

    return NextResponse.json(
      { message: 'Senha atualizada com sucesso' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Erro ao atualizar senha:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
