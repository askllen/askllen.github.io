import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    
    // Validação básica
    if (!data.name || !data.email || !data.password || !data.birthDate || 
        !data.documentType || !data.documentNumber || !data.street || 
        !data.number || !data.neighborhood || !data.city || 
        !data.state || !data.zipCode) {
      return NextResponse.json(
        { message: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      );
    }

    // Verificar se o e-mail já existe
    const existingUser = await env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(data.email).first();

    if (existingUser) {
      return NextResponse.json(
        { message: 'Este e-mail já está em uso' },
        { status: 409 }
      );
    }

    // Gerar ID único
    const userId = uuidv4();

    // Inserir usuário no banco de dados
    await env.DB.prepare(`
      INSERT INTO users (
        id, name, email, password, birth_date, document_type, document_number,
        street, number, complement, neighborhood, city, state, zip_code
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      data.name,
      data.email,
      data.password, // Já deve estar com hash
      data.birthDate,
      data.documentType,
      data.documentNumber,
      data.street,
      data.number,
      data.complement || '',
      data.neighborhood,
      data.city,
      data.state,
      data.zipCode
    ).run();

    return NextResponse.json(
      { message: 'Usuário cadastrado com sucesso' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Erro ao cadastrar usuário:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
