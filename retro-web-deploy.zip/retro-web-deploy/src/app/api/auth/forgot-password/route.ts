import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    
    // Validação básica
    if (!data.email) {
      return NextResponse.json(
        { message: 'E-mail é obrigatório' },
        { status: 400 }
      );
    }

    // Buscar usuário
    const user = await env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(data.email).first();

    if (!user) {
      return NextResponse.json(
        { message: 'Usuário não encontrado' },
        { status: 404 }
      );
    }

    // Gerar token de recuperação
    const token = uuidv4();
    const expires = new Date();
    expires.setHours(expires.getHours() + 1); // Token válido por 1 hora

    // Salvar token no banco
    await env.DB.prepare(`
      INSERT INTO verification_tokens (identifier, token, expires)
      VALUES (?, ?, ?)
    `).bind(
      data.email,
      token,
      expires.toISOString()
    ).run();

    // Em um ambiente real, enviaríamos um e-mail com o link de recuperação
    // Para fins de demonstração, retornamos o token na resposta
    return NextResponse.json(
      { 
        message: 'Instruções de recuperação enviadas para o e-mail',
        // Remover em produção:
        token: token,
        resetUrl: `/auth/reset-password?token=${token}&email=${encodeURIComponent(data.email)}`
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Erro ao processar recuperação de senha:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
