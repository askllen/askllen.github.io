import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import bcrypt from 'bcryptjs';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    
    // Validação básica
    if (!data.email || !data.token || !data.newPassword) {
      return NextResponse.json(
        { message: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      );
    }

    // Verificar token
    const verificationToken = await env.DB.prepare(
      "SELECT * FROM verification_tokens WHERE identifier = ? AND token = ? AND expires > datetime('now')"
    ).bind(data.email, data.token).first();

    if (!verificationToken) {
      return NextResponse.json(
        { message: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    // Buscar usuário
    const user = await env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(data.email).first();

    if (!user) {
      return NextResponse.json(
        { message: 'Usuário não encontrado' },
        { status: 404 }
      );
    }

    // Hash da nova senha
    const hashedPassword = await bcrypt.hash(data.newPassword, 10);

    // Atualizar senha
    await env.DB.prepare(`
      UPDATE users SET password = ? WHERE id = ?
    `).bind(
      hashedPassword,
      user.id
    ).run();

    // Remover token usado
    await env.DB.prepare(`
      DELETE FROM verification_tokens WHERE identifier = ? AND token = ?
    `).bind(
      data.email,
      data.token
    ).run();

    return NextResponse.json(
      { message: 'Senha redefinida com sucesso' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Erro ao redefinir senha:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
