import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import nodemailer from 'nodemailer';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    const { userId, emailProvider, imapServer, imapPort, smtpServer, smtpPort, username, password } = data;
    
    // Validação básica
    if (!userId || !emailProvider || !imapServer || !imapPort || !smtpServer || !smtpPort || !username || !password) {
      return NextResponse.json(
        { message: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      );
    }

    // Verificar se o usuário existe
    const user = await env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(userId).first();

    if (!user) {
      return NextResponse.json(
        { message: 'Usuário não encontrado' },
        { status: 404 }
      );
    }

    // Testar conexão SMTP
    try {
      const transporter = nodemailer.createTransport({
        host: smtpServer,
        port: parseInt(smtpPort),
        secure: parseInt(smtpPort) === 465,
        auth: {
          user: username,
          pass: password,
        },
      });

      await transporter.verify();
    } catch (error) {
      console.error('Erro ao verificar conexão SMTP:', error);
      return NextResponse.json(
        { message: 'Não foi possível conectar ao servidor SMTP. Verifique suas credenciais.' },
        { status: 400 }
      );
    }

    // Verificar se já existe configuração para este usuário
    const existingConfig = await env.DB.prepare(
      "SELECT * FROM email_settings WHERE user_id = ?"
    ).bind(userId).first();

    if (existingConfig) {
      // Atualizar configuração existente
      await env.DB.prepare(`
        UPDATE email_settings 
        SET email_provider = ?, imap_server = ?, imap_port = ?, 
            smtp_server = ?, smtp_port = ?, username = ?, password = ?
        WHERE user_id = ?
      `).bind(
        emailProvider,
        imapServer,
        imapPort,
        smtpServer,
        smtpPort,
        username,
        password,
        userId
      ).run();
    } else {
      // Inserir nova configuração
      await env.DB.prepare(`
        INSERT INTO email_settings (
          id, user_id, email_provider, imap_server, imap_port, 
          smtp_server, smtp_port, username, password
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        crypto.randomUUID(),
        userId,
        emailProvider,
        imapServer,
        imapPort,
        smtpServer,
        smtpPort,
        username,
        password
      ).run();
    }

    return NextResponse.json(
      { message: 'Configurações de e-mail salvas com sucesso' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Erro ao salvar configurações de e-mail:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
