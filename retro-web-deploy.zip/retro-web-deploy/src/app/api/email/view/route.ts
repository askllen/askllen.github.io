import { NextRequest, NextResponse } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import * as ImapClient from 'emailjs-imap-client';

export async function POST(request: NextRequest) {
  try {
    const { env } = getCloudflareContext({ env: request.nextUrl.searchParams });
    if (!env?.DB) {
      return NextResponse.json(
        { message: 'Banco de dados não disponível' },
        { status: 500 }
      );
    }

    const data = await request.json();
    const { userId, uid, folder = 'INBOX' } = data;
    
    // Validação básica
    if (!userId || !uid) {
      return NextResponse.json(
        { message: 'ID do usuário e UID da mensagem são obrigatórios' },
        { status: 400 }
      );
    }

    // Buscar configurações de e-mail do usuário
    const emailSettings = await env.DB.prepare(
      "SELECT * FROM email_settings WHERE user_id = ?"
    ).bind(userId).first();

    if (!emailSettings) {
      return NextResponse.json(
        { message: 'Configurações de e-mail não encontradas' },
        { status: 404 }
      );
    }

    // Configurar cliente IMAP
    const client = new ImapClient.default(
      emailSettings.imap_server,
      parseInt(emailSettings.imap_port),
      {
        auth: {
          user: emailSettings.username,
          pass: emailSettings.password,
        },
        useSecureTransport: parseInt(emailSettings.imap_port) === 993,
      }
    );

    try {
      // Conectar ao servidor IMAP
      await client.connect();
      
      // Selecionar pasta
      await client.selectMailbox(folder);
      
      // Buscar mensagem específica
      const messages = await client.listMessages(
        folder,
        uid,
        ['uid', 'envelope', 'bodystructure', 'flags', 'body[]']
      );
      
      if (!messages || messages.length === 0) {
        return NextResponse.json(
          { message: 'Mensagem não encontrada' },
          { status: 404 }
        );
      }
      
      const message = messages[0];
      
      // Processar anexos se existirem
      let attachments = [];
      if (message.bodystructure.childNodes) {
        attachments = message.bodystructure.childNodes
          .filter(part => part.disposition && part.disposition.type.toLowerCase() === 'attachment')
          .map(part => ({
            filename: part.disposition.params.filename,
            contentType: part.type + '/' + part.subtype,
            size: part.size,
            partId: part.partID
          }));
      }
      
      // Processar mensagem para formato mais amigável
      const processedMessage = {
        uid: message.uid,
        subject: message.envelope.subject,
        from: message.envelope.from.map(f => ({ name: f.name, email: f.mailbox + '@' + f.host })),
        to: message.envelope.to.map(t => ({ name: t.name, email: t.mailbox + '@' + t.host })),
        cc: message.envelope.cc ? message.envelope.cc.map(c => ({ name: c.name, email: c.mailbox + '@' + c.host })) : [],
        date: message.envelope.date,
        flags: message.flags,
        body: message['body[]'],
        attachments: attachments,
      };
      
      // Desconectar
      client.close();
      
      return NextResponse.json(
        { message: processedMessage },
        { status: 200 }
      );
    } catch (error) {
      console.error('Erro ao buscar e-mail:', error);
      return NextResponse.json(
        { message: 'Erro ao buscar e-mail. Verifique suas configurações.' },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return NextResponse.json(
      { message: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
