import { Server } from 'socket.io';
import Filter from 'bad-words';

const filter = new Filter();

// Lista de palavras ofensivas em português para adicionar ao filtro
const palavrasOfensivas = [
  'palavrão1', 'palavrão2', 'palavrão3', 
  // Adicione mais palavras conforme necessário
];

// Adicionar palavras ofensivas em português ao filtro
filter.addWords(...palavrasOfensivas);

export default function SocketHandler(req, res) {
  // Verificar se o Socket.io já está inicializado
  if (res.socket.server.io) {
    console.log('Socket já está inicializado');
    res.end();
    return;
  }

  // Inicializar o Socket.io
  const io = new Server(res.socket.server, {
    path: '/api/socket',
    addTrailingSlash: false,
  });
  res.socket.server.io = io;

  // Armazenar usuários conectados
  const users = new Map();
  
  // Armazenar mensagens recentes para novos usuários
  const recentMessages = {
    private: new Map(), // userId_userId -> mensagens
    rooms: new Map(),   // roomId -> mensagens
  };

  // Limite de mensagens recentes a armazenar
  const MESSAGE_LIMIT = 50;

  io.on('connection', (socket) => {
    console.log('Novo cliente conectado:', socket.id);
    let userId = null;
    let userName = null;

    // Autenticar usuário
    socket.on('authenticate', (data) => {
      userId = data.userId;
      userName = data.userName;
      
      // Armazenar informações do usuário
      users.set(userId, {
        socketId: socket.id,
        userName: userName,
        online: true
      });
      
      // Notificar todos os usuários sobre o novo status
      io.emit('user_status', {
        userId,
        userName,
        online: true
      });
      
      // Enviar lista de usuários online para o usuário que acabou de se conectar
      const onlineUsers = [];
      users.forEach((user, id) => {
        if (id !== userId && user.online) {
          onlineUsers.push({
            userId: id,
            userName: user.userName,
            online: true
          });
        }
      });
      
      socket.emit('online_users', onlineUsers);
      
      console.log(`Usuário autenticado: ${userName} (${userId})`);
    });

    // Enviar mensagem privada
    socket.on('private_message', (data) => {
      const { to, message, attachment } = data;
      
      // Filtrar palavras ofensivas
      const filteredMessage = filter.clean(message);
      
      // Criar objeto de mensagem
      const messageObj = {
        from: userId,
        fromName: userName,
        to,
        message: filteredMessage,
        attachment,
        timestamp: new Date().toISOString()
      };
      
      // Armazenar mensagem no histórico
      const chatId = [userId, to].sort().join('_');
      if (!recentMessages.private.has(chatId)) {
        recentMessages.private.set(chatId, []);
      }
      
      const messages = recentMessages.private.get(chatId);
      messages.push(messageObj);
      
      // Limitar número de mensagens armazenadas
      if (messages.length > MESSAGE_LIMIT) {
        messages.shift();
      }
      
      // Enviar para o destinatário se estiver online
      const recipient = users.get(to);
      if (recipient && recipient.online) {
        io.to(recipient.socketId).emit('private_message', messageObj);
      }
      
      // Enviar confirmação para o remetente
      socket.emit('message_sent', {
        id: messageObj.timestamp,
        to
      });
    });

    // Obter histórico de mensagens privadas
    socket.on('get_private_history', (data) => {
      const { withUserId } = data;
      const chatId = [userId, withUserId].sort().join('_');
      
      const messages = recentMessages.private.get(chatId) || [];
      socket.emit('private_history', {
        withUserId,
        messages
      });
    });

    // Entrar em uma sala
    socket.on('join_room', (data) => {
      const { roomId } = data;
      
      // Entrar na sala do Socket.io
      socket.join(roomId);
      
      // Enviar histórico de mensagens da sala
      const messages = recentMessages.rooms.get(roomId) || [];
      socket.emit('room_history', {
        roomId,
        messages
      });
      
      console.log(`Usuário ${userName} (${userId}) entrou na sala ${roomId}`);
    });

    // Enviar mensagem para sala
    socket.on('room_message', (data) => {
      const { roomId, message, attachment } = data;
      
      // Filtrar palavras ofensivas
      const filteredMessage = filter.clean(message);
      
      // Criar objeto de mensagem
      const messageObj = {
        from: userId,
        fromName: userName,
        roomId,
        message: filteredMessage,
        attachment,
        timestamp: new Date().toISOString()
      };
      
      // Armazenar mensagem no histórico
      if (!recentMessages.rooms.has(roomId)) {
        recentMessages.rooms.set(roomId, []);
      }
      
      const messages = recentMessages.rooms.get(roomId);
      messages.push(messageObj);
      
      // Limitar número de mensagens armazenadas
      if (messages.length > MESSAGE_LIMIT) {
        messages.shift();
      }
      
      // Enviar para todos na sala
      io.to(roomId).emit('room_message', messageObj);
    });

    // Sair de uma sala
    socket.on('leave_room', (data) => {
      const { roomId } = data;
      socket.leave(roomId);
      console.log(`Usuário ${userName} (${userId}) saiu da sala ${roomId}`);
    });

    // Lidar com desconexão
    socket.on('disconnect', () => {
      if (userId) {
        const user = users.get(userId);
        if (user) {
          user.online = false;
          
          // Notificar todos os usuários sobre o status offline
          io.emit('user_status', {
            userId,
            userName,
            online: false
          });
          
          console.log(`Usuário desconectado: ${userName} (${userId})`);
        }
      }
    });
  });

  console.log('Socket.io inicializado');
  res.end();
}
