import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import ChatContext from '@/components/chat/ChatContext';

export default function ChatRooms() {
  const { data: session } = useSession();
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [message, setMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [error, setError] = useState('');
  const messagesEndRef = useRef(null);
  
  // Lista de salas disponíveis
  const rooms = [
    { id: 'room1', name: 'St@rt, o início!', description: 'Sala para iniciantes e boas-vindas' },
    { id: 'room2', name: 'The G@m3', description: 'Sala para discussão de jogos' },
    { id: 'room3', name: 'Filmes e Séries', description: 'Sala para discussão de filmes e séries' },
    { id: 'room4', name: 'Amizade', description: 'Sala para fazer novos amigos' },
    { id: 'room5', name: 'Namoro', description: 'Sala para conhecer pessoas especiais' }
  ];

  // Função para formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit'
    });
  };

  // Rolar para a última mensagem quando novas mensagens chegarem
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [selectedRoom]);

  // Processar anexo
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    
    if (!file) {
      setAttachment(null);
      return;
    }
    
    // Verificar tipo de arquivo (apenas imagens e PDFs)
    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
      setError('Apenas imagens e PDFs são permitidos como anexos.');
      setAttachment(null);
      return;
    }
    
    // Verificar tamanho (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('O arquivo é muito grande. Tamanho máximo: 5MB.');
      setAttachment(null);
      return;
    }
    
    // Processar arquivo
    const reader = new FileReader();
    reader.onloadend = () => {
      setAttachment({
        filename: file.name,
        content: reader.result.split(',')[1], // Remover prefixo data:...;base64,
        type: file.type,
        size: file.size,
        preview: reader.result
      });
      setError('');
    };
    reader.readAsDataURL(file);
  };

  // Remover anexo
  const removeAttachment = () => {
    setAttachment(null);
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  return (
    <ChatContext>
      {(chat) => (
        <div className="min-h-screen">
          <div className="retro-header">
            <h1 className="text-3xl">SALAS DE BATE-PAPO</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Lista de salas */}
            <div className="md:col-span-1">
              <div className="retro-card">
                <h2 className="text-xl font-bold mb-4">SALAS DISPONÍVEIS</h2>
                
                <ul className="border-2 border-black">
                  {rooms.map(room => (
                    <li 
                      key={room.id}
                      className={`p-2 border-b-2 border-black cursor-pointer hover:bg-yellow-100 ${selectedRoom?.id === room.id ? 'bg-yellow-200' : ''}`}
                      onClick={() => {
                        // Se já estava em uma sala, sair dela
                        if (selectedRoom) {
                          chat.leaveRoom(selectedRoom.id);
                        }
                        
                        // Entrar na nova sala
                        setSelectedRoom(room);
                        chat.joinRoom(room.id);
                      }}
                    >
                      <div>
                        <strong>{room.name}</strong>
                        <p className="text-sm text-gray-600">{room.description}</p>
                      </div>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-4">
                  <Link href="/chat" className="retro-button bg-blue-400 w-full block text-center">
                    CHAT PRIVADO
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Área de chat */}
            <div className="md:col-span-3">
              <div className="retro-card">
                {selectedRoom ? (
                  <>
                    <div className="border-b-2 border-black pb-2 mb-4">
                      <h2 className="text-xl font-bold">Sala: {selectedRoom.name}</h2>
                      <p className="text-sm text-gray-600">{selectedRoom.description}</p>
                    </div>
                    
                    <div className="retro-chat-container">
                      {chat.roomMessages[selectedRoom.id]?.length > 0 ? (
                        chat.roomMessages[selectedRoom.id].map((msg, index) => (
                          <div 
                            key={index}
                            className={`retro-message ${msg.from === session.user.id ? 'retro-message-sent' : 'retro-message-received'}`}
                          >
                            <div className="flex justify-between items-start">
                              <strong>{msg.fromName}</strong>
                              <small>{formatDate(msg.timestamp)}</small>
                            </div>
                            <p>{msg.message}</p>
                            
                            {msg.attachment && (
                              <div className="mt-2 border-t border-black pt-1">
                                {msg.attachment.type?.startsWith('image/') ? (
                                  <img 
                                    src={`data:${msg.attachment.type};base64,${msg.attachment.content}`}
                                    alt="Anexo"
                                    className="max-w-full max-h-40 border border-black"
                                  />
                                ) : (
                                  <div className="flex items-center">
                                    <span className="mr-2">📎</span>
                                    <span>{msg.attachment.filename}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-gray-500">Nenhuma mensagem nesta sala ainda. Seja o primeiro a falar!</p>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                    
                    {error && (
                      <div className="bg-red-100 border-2 border-red-500 text-red-700 p-2 my-2 text-center">
                        {error}
                      </div>
                    )}
                    
                    {attachment && (
                      <div className="border-2 border-black p-2 my-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <span className="mr-2">📎</span>
                            <span>{attachment.filename} ({Math.round(attachment.size / 1024)} KB)</span>
                          </div>
                          <button 
                            className="text-red-500"
                            onClick={removeAttachment}
                          >
                            Remover
                          </button>
                        </div>
                        
                        {attachment.type.startsWith('image/') && (
                          <img 
                            src={attachment.preview}
                            alt="Preview"
                            className="max-w-full max-h-40 mt-2 border border-black"
                          />
                        )}
                      </div>
                    )}
                    
                    <div className="flex mt-4">
                      <input 
                        type="text"
                        className="retro-input flex-grow mr-2"
                        placeholder="Digite sua mensagem..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && message.trim()) {
                            chat.sendRoomMessage(selectedRoom.id, message, attachment);
                            setMessage('');
                            setAttachment(null);
                            scrollToBottom();
                          }
                        }}
                      />
                      <label className="retro-button bg-blue-400 mr-2 cursor-pointer">
                        📎
                        <input 
                          type="file"
                          className="hidden"
                          onChange={handleFileChange}
                          accept="image/*,application/pdf"
                        />
                      </label>
                      <button 
                        className="retro-button bg-green-400"
                        disabled={!message.trim() && !attachment}
                        onClick={() => {
                          if (message.trim() || attachment) {
                            chat.sendRoomMessage(selectedRoom.id, message, attachment);
                            setMessage('');
                            setAttachment(null);
                            scrollToBottom();
                          }
                        }}
                      >
                        ENVIAR
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-10">
                    <h2 className="text-xl font-bold mb-4">Selecione uma sala para entrar</h2>
                    <p className="text-gray-500">
                      Clique em uma sala na lista à esquerda para participar de um bate-papo em grupo.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </ChatContext>
  );
}
