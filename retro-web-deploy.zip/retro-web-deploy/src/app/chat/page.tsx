import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import ChatContext from '@/components/chat/ChatContext';

export default function PrivateChat() {
  const { data: session } = useSession();
  const [selectedUser, setSelectedUser] = useState(null);
  const [message, setMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [error, setError] = useState('');
  const messagesEndRef = useRef(null);

  // Função para formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit'
    });
  };

  // Rolar para a última mensagem quando novas mensagens chegarem
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [selectedUser]);

  // Processar anexo
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    
    if (!file) {
      setAttachment(null);
      return;
    }
    
    // Verificar tipo de arquivo (apenas imagens e PDFs)
    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
      setError('Apenas imagens e PDFs são permitidos como anexos.');
      setAttachment(null);
      return;
    }
    
    // Verificar tamanho (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('O arquivo é muito grande. Tamanho máximo: 5MB.');
      setAttachment(null);
      return;
    }
    
    // Processar arquivo
    const reader = new FileReader();
    reader.onloadend = () => {
      setAttachment({
        filename: file.name,
        content: reader.result.split(',')[1], // Remover prefixo data:...;base64,
        type: file.type,
        size: file.size,
        preview: reader.result
      });
      setError('');
    };
    reader.readAsDataURL(file);
  };

  // Remover anexo
  const removeAttachment = () => {
    setAttachment(null);
  };

  if (!session) {
    return (
      <div className="retro-card">
        <p className="text-center">Você precisa estar logado para acessar esta página.</p>
        <div className="mt-4 text-center">
          <Link href="/auth/login" className="retro-button bg-blue-400 inline-block">
            FAZER LOGIN
          </Link>
        </div>
      </div>
    );
  }

  return (
    <ChatContext>
      {(chat) => (
        <div className="min-h-screen">
          <div className="retro-header">
            <h1 className="text-3xl">COMUNICADOR RETRO</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Lista de usuários online */}
            <div className="md:col-span-1">
              <div className="retro-card">
                <h2 className="text-xl font-bold mb-4">USUÁRIOS ONLINE</h2>
                
                {chat.onlineUsers.length === 0 ? (
                  <p className="text-center text-gray-500">Nenhum usuário online no momento.</p>
                ) : (
                  <ul className="border-2 border-black">
                    {chat.onlineUsers.map(user => (
                      <li 
                        key={user.userId}
                        className={`p-2 border-b-2 border-black cursor-pointer hover:bg-yellow-100 ${selectedUser?.userId === user.userId ? 'bg-yellow-200' : ''}`}
                        onClick={() => {
                          setSelectedUser(user);
                          chat.getPrivateMessageHistory(user.userId);
                        }}
                      >
                        <div className="flex items-center">
                          <div className={`w-3 h-3 rounded-full ${user.online ? 'bg-green-500' : 'bg-gray-500'} mr-2`}></div>
                          <span>{user.userName}</span>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
                
                <div className="mt-4">
                  <Link href="/rooms" className="retro-button bg-blue-400 w-full block text-center">
                    SALAS DE BATE-PAPO
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Área de chat */}
            <div className="md:col-span-3">
              <div className="retro-card">
                {selectedUser ? (
                  <>
                    <div className="border-b-2 border-black pb-2 mb-4">
                      <h2 className="text-xl font-bold">Chat com {selectedUser.userName}</h2>
                    </div>
                    
                    <div className="retro-chat-container">
                      {chat.privateMessages[selectedUser.userId]?.length > 0 ? (
                        chat.privateMessages[selectedUser.userId].map((msg, index) => (
                          <div 
                            key={index}
                            className={`retro-message ${msg.from === session.user.id ? 'retro-message-sent' : 'retro-message-received'}`}
                          >
                            <div className="flex justify-between items-start">
                              <strong>{msg.fromName}</strong>
                              <small>{formatDate(msg.timestamp)}</small>
                            </div>
                            <p>{msg.message}</p>
                            
                            {msg.attachment && (
                              <div className="mt-2 border-t border-black pt-1">
                                {msg.attachment.type?.startsWith('image/') ? (
                                  <img 
                                    src={`data:${msg.attachment.type};base64,${msg.attachment.content}`}
                                    alt="Anexo"
                                    className="max-w-full max-h-40 border border-black"
                                  />
                                ) : (
                                  <div className="flex items-center">
                                    <span className="mr-2">📎</span>
                                    <span>{msg.attachment.filename}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-gray-500">Nenhuma mensagem ainda. Comece a conversar!</p>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                    
                    {error && (
                      <div className="bg-red-100 border-2 border-red-500 text-red-700 p-2 my-2 text-center">
                        {error}
                      </div>
                    )}
                    
                    {attachment && (
                      <div className="border-2 border-black p-2 my-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <span className="mr-2">📎</span>
                            <span>{attachment.filename} ({Math.round(attachment.size / 1024)} KB)</span>
                          </div>
                          <button 
                            className="text-red-500"
                            onClick={removeAttachment}
                          >
                            Remover
                          </button>
                        </div>
                        
                        {attachment.type.startsWith('image/') && (
                          <img 
                            src={attachment.preview}
                            alt="Preview"
                            className="max-w-full max-h-40 mt-2 border border-black"
                          />
                        )}
                      </div>
                    )}
                    
                    <div className="flex mt-4">
                      <input 
                        type="text"
                        className="retro-input flex-grow mr-2"
                        placeholder="Digite sua mensagem..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && message.trim()) {
                            chat.sendPrivateMessage(selectedUser.userId, message, attachment);
                            setMessage('');
                            setAttachment(null);
                            scrollToBottom();
                          }
                        }}
                      />
                      <label className="retro-button bg-blue-400 mr-2 cursor-pointer">
                        📎
                        <input 
                          type="file"
                          className="hidden"
                          onChange={handleFileChange}
                          accept="image/*,application/pdf"
                        />
                      </label>
                      <button 
                        className="retro-button bg-green-400"
                        disabled={!message.trim() && !attachment}
                        onClick={() => {
                          if (message.trim() || attachment) {
                            chat.sendPrivateMessage(selectedUser.userId, message, attachment);
                            setMessage('');
                            setAttachment(null);
                            scrollToBottom();
                          }
                        }}
                      >
                        ENVIAR
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-10">
                    <h2 className="text-xl font-bold mb-4">Selecione um usuário para iniciar uma conversa</h2>
                    <p className="text-gray-500">
                      Clique em um usuário na lista à esquerda para iniciar um chat privado.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </ChatContext>
  );
}
