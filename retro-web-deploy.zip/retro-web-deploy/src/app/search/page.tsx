'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Search() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e) => {
    e.preventDefault();
    
    if (!query.trim()) return;
    
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      
      if (!response.ok) {
        throw new Error('Erro ao buscar resultados');
      }
      
      const data = await response.json();
      setResults(data);
    } catch (err) {
      console.error('Erro na busca:', err);
      setError('Ocorreu um erro ao buscar resultados. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <div className="retro-header">
        <h1 className="text-3xl">BUSCA RETRO</h1>
      </div>

      <div className="retro-card">
        <form onSubmit={handleSearch} className="mb-6">
          <div className="flex">
            <input 
              type="text"
              className="retro-input flex-grow mr-2"
              placeholder="Digite sua busca..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button 
              type="submit" 
              className="retro-button bg-green-400"
              disabled={loading}
            >
              {loading ? 'BUSCANDO...' : 'BUSCAR'}
            </button>
          </div>
        </form>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-700 p-3 mb-4 text-center">
            {error}
          </div>
        )}
        
        {results && (
          <div className="search-results">
            <h2 className="text-xl font-bold mb-4">Resultados da Busca</h2>
            
            {/* Resposta direta (se disponível) */}
            {results.Answer && (
              <div className="retro-message mb-4 p-4 border-2 border-blue-500 bg-blue-100">
                <h3 className="font-bold">Resposta Direta:</h3>
                <p>{results.Answer}</p>
              </div>
            )}
            
            {/* Resumo do tópico (se disponível) */}
            {results.AbstractText && (
              <div className="mb-4 p-4 border-2 border-black">
                <h3 className="font-bold">{results.Heading || 'Resumo'}</h3>
                <p>{results.AbstractText}</p>
                {results.AbstractURL && (
                  <a 
                    href={results.AbstractURL} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Fonte: {results.AbstractSource}
                  </a>
                )}
              </div>
            )}
            
            {/* Resultados relacionados */}
            {results.RelatedTopics && results.RelatedTopics.length > 0 ? (
              <div>
                <h3 className="font-bold mb-2">Resultados Relacionados:</h3>
                <ul className="border-2 border-black">
                  {results.RelatedTopics.map((topic, index) => (
                    <li key={index} className="p-2 border-b-2 border-black last:border-b-0">
                      {topic.Result ? (
                        <div dangerouslySetInnerHTML={{ __html: topic.Result }} />
                      ) : (
                        <div>
                          <p>{topic.Text}</p>
                          {topic.FirstURL && (
                            <a 
                              href={topic.FirstURL} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-blue-500 hover:underline"
                            >
                              Visitar
                            </a>
                          )}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              !results.Answer && !results.AbstractText && (
                <p className="text-center text-gray-500">Nenhum resultado encontrado para sua busca.</p>
              )
            )}
            
            {/* Definição (se disponível) */}
            {results.Definition && (
              <div className="mt-4 p-4 border-2 border-black">
                <h3 className="font-bold">Definição:</h3>
                <p>{results.Definition}</p>
                {results.DefinitionURL && (
                  <a 
                    href={results.DefinitionURL} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Fonte: {results.DefinitionSource}
                  </a>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
