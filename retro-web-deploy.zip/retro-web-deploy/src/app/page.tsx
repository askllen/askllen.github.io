import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Header com logo */}
      <header className="retro-header flex items-center justify-between">
        <div className="flex items-center">
          <div className="mr-4">
            <Image 
              src="/images/retro-logo.png" 
              alt="Retro Web Logo" 
              width={80} 
              height={80}
              className="inline-block"
            />
          </div>
          <h1 className="text-4xl md:text-6xl">RETRO WEB</h1>
        </div>
      </header>

      {/* Menu de navegação */}
      <nav className="retro-nav">
        <Link href="/" className="retro-nav-item">Início</Link>
        <Link href="/chat" className="retro-nav-item">Chat</Link>
        <Link href="/rooms" className="retro-nav-item">Salas</Link>
        <Link href="/email" className="retro-nav-item">E-mail</Link>
        <Link href="/search" className="retro-nav-item">Busca</Link>
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Coluna da esquerda - Notícias */}
        <div className="md:col-span-2">
          <div className="retro-card">
            <h2 className="text-2xl font-bold mb-4">TÍTULO DA NOTÍCIA</h2>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="w-full md:w-1/3">
                <div className="bg-gray-200 h-48 flex items-center justify-center border-2 border-black">
                  [Imagem da Notícia]
                </div>
              </div>
              <div className="w-full md:w-2/3">
                <p>Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok.</p>
                <p className="mt-2">Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum is ok, is ok Lorem ipsum.</p>
                <Link href="#" className="retro-link mt-2 inline-block">Leia +</Link>
              </div>
            </div>
          </div>

          {/* Últimas notícias */}
          <div className="retro-card mt-4 bg-red-500 text-white">
            <h2 className="text-2xl font-bold mb-2">ÚLTIMAS NOTÍCIAS</h2>
            <ul>
              <li className="mb-2">
                <Link href="#" className="text-white hover:underline">
                  Título da Notícia alongado até o final da linha, precisando ...
                </Link>
              </li>
              <li className="mb-2">
                <Link href="#" className="text-white hover:underline">
                  Título da Notícia alongado até o final da linha, precisando ...
                </Link>
              </li>
              <li className="mb-2">
                <Link href="#" className="text-white hover:underline">
                  Título da Notícia alongado até o final da linha, precisando ...
                </Link>
              </li>
            </ul>
          </div>

          {/* Previsão do tempo */}
          <div className="retro-card mt-4">
            <h2 className="text-2xl font-bold mb-2">PREVISÃO DO TEMPO</h2>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="font-bold">Rio de Janeiro, RJ</p>
                <p>27°</p>
                <p>Características da previsão do tempo segundo sites seguros.</p>
              </div>
              <div>
                <p className="font-bold">São Paulo, SP</p>
                <p>19°</p>
                <p>Características da previsão do tempo segundo sites seguros.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Coluna da direita - Login e Recursos */}
        <div className="md:col-span-1">
          {/* Tela de acesso */}
          <div className="retro-card border-4 border-yellow-400 bg-yellow-100">
            <h2 className="text-2xl font-bold mb-4 text-center">TELA DE ACESSO</h2>
            <form className="retro-form">
              <div className="retro-form-group">
                <label className="retro-form-label">NOME DE TELA:</label>
                <input type="text" className="retro-input" />
              </div>
              <div className="retro-form-group">
                <label className="retro-form-label">SENHA:</label>
                <input type="password" className="retro-input" />
              </div>
              <div className="text-right">
                <Link href="#" className="text-red-500 text-sm">ESQUECEU A SENHA?</Link>
              </div>
              <div className="flex justify-between mt-4">
                <button type="button" className="retro-button bg-yellow-400">CADASTRE-SE</button>
                <button type="submit" className="retro-button bg-green-400">ENTRAR</button>
              </div>
            </form>
          </div>

          {/* Chat Retro */}
          <div className="retro-card mt-4">
            <h2 className="text-2xl font-bold mb-2 text-center text-red-500">CHAT RETRO</h2>
            <p className="text-center mb-2">Encontre amigos ou faça novos... Let's ch@t!</p>
            <ul>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">Sala: St@rt, o início!</Link>
              </li>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">Sala: The G@m3</Link>
              </li>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">Sala: Filmes e Séries</Link>
              </li>
            </ul>
            <div className="text-center mt-4">
              <button className="retro-button bg-yellow-400">Entre Agora!</button>
            </div>
          </div>

          {/* Retro Play */}
          <div className="retro-card mt-4">
            <h2 className="text-2xl font-bold mb-2 text-center text-red-500">RETRO PLAY</h2>
            <p className="text-center mb-2">Os melhores jogos retrô, bora jogar?</p>
            <ul>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">❤️ Super Mario Bross</Link>
              </li>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">❤️ Sonic</Link>
              </li>
              <li className="mb-1">
                <Link href="#" className="text-red-500 hover:underline">❤️ Alex kidd in Miracle W.</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Rodapé */}
      <footer className="mt-8 text-center border-t-2 border-black pt-4">
        <p>© 2025 Retro Web - Todos os direitos reservados</p>
      </footer>
    </main>
  );
}
