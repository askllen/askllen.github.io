// Utilitário para obter o contexto do Cloudflare
export function getCloudflareContext(context: any) {
  // Para ambiente de desenvolvimento local
  if (process.env.NODE_ENV === 'development') {
    return {
      env: {
        DB: context?.env?.DB || null
      }
    };
  }

  // Para ambiente de produção
  return {
    env: context?.env || null
  };
}
