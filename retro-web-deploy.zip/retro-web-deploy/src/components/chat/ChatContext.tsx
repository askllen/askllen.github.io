import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import io from 'socket.io-client';

let socket;

export default function ChatContext({ children }) {
  const { data: session } = useSession();
  const [connected, setConnected] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [privateMessages, setPrivateMessages] = useState({});
  const [roomMessages, setRoomMessages] = useState({});
  const socketInitialized = useRef(false);

  // Inicializar Socket.io
  useEffect(() => {
    if (!session?.user?.id || socketInitialized.current) return;

    const initSocket = async () => {
      await fetch('/api/socket');
      
      socket = io({
        path: '/api/socket',
      });

      socket.on('connect', () => {
        console.log('Socket conectado');
        setConnected(true);
        
        // Autenticar usuário
        socket.emit('authenticate', {
          userId: session.user.id,
          userName: session.user.name
        });
      });

      socket.on('online_users', (users) => {
        setOnlineUsers(users);
      });

      socket.on('user_status', (user) => {
        setOnlineUsers(prev => {
          // Verificar se o usuário já está na lista
          const exists = prev.some(u => u.userId === user.userId);
          
          if (user.online && !exists) {
            // Adicionar novo usuário online
            return [...prev, user];
          } else if (user.online && exists) {
            // Atualizar status para online
            return prev.map(u => 
              u.userId === user.userId ? { ...u, online: true } : u
            );
          } else {
            // Atualizar status para offline
            return prev.map(u => 
              u.userId === user.userId ? { ...u, online: false } : u
            );
          }
        });
      });

      socket.on('private_message', (message) => {
        setPrivateMessages(prev => {
          const otherUserId = message.from;
          const messages = prev[otherUserId] || [];
          return {
            ...prev,
            [otherUserId]: [...messages, message]
          };
        });
      });

      socket.on('private_history', (data) => {
        const { withUserId, messages } = data;
        setPrivateMessages(prev => ({
          ...prev,
          [withUserId]: messages
        }));
      });

      socket.on('room_message', (message) => {
        setRoomMessages(prev => {
          const roomId = message.roomId;
          const messages = prev[roomId] || [];
          return {
            ...prev,
            [roomId]: [...messages, message]
          };
        });
      });

      socket.on('room_history', (data) => {
        const { roomId, messages } = data;
        setRoomMessages(prev => ({
          ...prev,
          [roomId]: messages
        }));
      });

      socket.on('disconnect', () => {
        console.log('Socket desconectado');
        setConnected(false);
      });

      socketInitialized.current = true;
    };

    initSocket();

    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [session]);

  // Funções para interagir com o chat
  const sendPrivateMessage = (toUserId, message, attachment = null) => {
    if (!socket || !connected) return false;
    
    socket.emit('private_message', {
      to: toUserId,
      message,
      attachment
    });
    
    // Adicionar mensagem à lista local
    const newMessage = {
      from: session.user.id,
      fromName: session.user.name,
      to: toUserId,
      message,
      attachment,
      timestamp: new Date().toISOString()
    };
    
    setPrivateMessages(prev => {
      const messages = prev[toUserId] || [];
      return {
        ...prev,
        [toUserId]: [...messages, newMessage]
      };
    });
    
    return true;
  };

  const getPrivateMessageHistory = (withUserId) => {
    if (!socket || !connected) return;
    
    socket.emit('get_private_history', {
      withUserId
    });
  };

  const joinRoom = (roomId) => {
    if (!socket || !connected) return;
    
    socket.emit('join_room', {
      roomId
    });
  };

  const leaveRoom = (roomId) => {
    if (!socket || !connected) return;
    
    socket.emit('leave_room', {
      roomId
    });
  };

  const sendRoomMessage = (roomId, message, attachment = null) => {
    if (!socket || !connected) return false;
    
    socket.emit('room_message', {
      roomId,
      message,
      attachment
    });
    
    return true;
  };

  // Contexto de chat para compartilhar com componentes filhos
  const chatContext = {
    connected,
    onlineUsers,
    privateMessages,
    roomMessages,
    sendPrivateMessage,
    getPrivateMessageHistory,
    joinRoom,
    leaveRoom,
    sendRoomMessage
  };

  return (
    <div className="chat-context">
      {children(chatContext)}
    </div>
  );
}
